#!C:/Python27/python.exe
print 'Content-Type:text/html\n';

from neo4j import GraphDatabase
import urlparse, os;

try:
	id = int(urlparse.parse_qs(os.environ['QUERY_STRING'])['id'][0]);
	name = urlparse.parse_qs(os.environ['QUERY_STRING'])['name'][0];
	#print id;

	print '<!DOCTYPE html>';
	print "<html lang='en'>";
	print "<head>";
	print "<title>IMAGE CLOUD</title>";
	print '<style type="text/css">';
	print 'li.big';
	print '{';
	print 'font-size: 2em;';
	print '}';
	#print 'body';
	#print '{';
	#print 'background-color:wheat;';
	#print '}';
	#print 'background-image:url("http://localhost/imgs/3.jpg");';
	#print 'background-attachement:fixed;';
	#print 'background-size:950px 700px;';
	#print 'background-repeat:no-repeat;'
	#print 'opacity:1;';
	 #y isn't background image getting set?
	#print '}';
	print 'li.small';
	print '{';
	print 'font-size: 1.2em;';
	print '}';
	print 'li.medium';
	print '{';
	print 'font-size:1.5em;';
	print '}';
	print '#img';
	print '{';
	#print 'position:absolute;';
	#print 'top:50px;';
	#print 'left:50px;';
	print 'border-color:black;';
	print 'border-width:medium;';
	print 'border-style:solid;';
	print '}';
	print '#tags';
	print '{';
	print 'position:absolute;';
	print 'top:50px;';
	print 'left:50px;';
	print '}';
	print '#left';
	print '{';
	print 'border-right-style:dashed;';
	print 'border-right-width:thick;';
	print 'border-right-color:navy;';
	print '}';
	print 'table';
	print '{';
	print 'background-color:wheat;';
	print 'border-color:purple;';
	print 'border-style:solid;';
	print 'border-width:thick;';
	print 'padding:0px;';
	print '}';
	print 'td';
	print '{';
	print 'padding:0px;';
	print '}';
	print 'tr';
	print '{';
	print 'padding:0px;';
	print '}';
	print '#name';
	print '{';
	print 'color:black;';
	print 'font-family:Bradley Hand ITC;';
	print 'font-size:1.6em;';
	print '}';
	print 'a';
	print '{';
	print 'color:black;';
	print '}';
	print '</style>';
	print '<script type="text/javascript" src="http://localhost/tagcanvas.js"></script>';
			
	print '<script type="text/javascript">'	;
	print 'function init(){';
	print '//try';
	print '//{';
	print "TagCanvas.Start('cloud','tags',{textColour: 'darkturquoise',outlineColour: '#ff00ff',reverse: true,depth: 0.8,maxSpeed: 0.05,weight: true,weightMode:'both',shape: 'sphere',weightGradient:{1:'darkturquoise', 0:'teal'},noSelect: true,textHeight: 20,textFont: 'Comic Sans MS',hideTags: true,shadow: 'lightgrey',shadowOffset:[3,3],shadowBlur:1});";
	print '//}' ;
	print '//catch(e)'; 
	print '//{';
	print '// something went wrong, hide the canvas container';
	print "// document.getElementById('outer').style.display = 'none';";
	print '//}'
	print '}'
	print '</script>'
	print '</head>'
		
	print "<body onload='init()'>"
	#print "<img src='http://localhost/img/1.jpg' width='50' id='img'></img>";
	db = GraphDatabase("D:\\preethi\\data\\graph1");
	link = db.node[id]["link"];

	print "<table align='center'>"
	print "<tr>"
	print "<td id='left' width='400px' align='center'>"
	print "<b id='name'>" + name.upper() + "</b><br/><br/>";
	print "<img align='center' src='http://localhost/demo/images/" + name + ".jpg' width='180' height='180' id='img'>"
	print "<br/><br/><br/><a target='_blank' href='" + link + "'>HOME PAGE</a>";
	print "</td>";
	print "<td>";
	with db.transaction:
		author = db.node[id];
		relationships = author.relationships.outgoing;

		print '<div id="outer">';
		print '<canvas id="cloud" width="800" height="600">';
		print '</canvas>';
		print '</div>';
		
		print "<div id='tags'>";
		print "<ul id='keywords' type='none'>";
		for rel in relationships:
			i = 0;
			if str(rel.type) == 'author_of':
				paper = rel.end;
				keywords = paper['key'];
				
				while i < len(keywords):
					if i == 0:
						print "<li class='big'><a>" + keywords[i] + "</a></li>";
					else:
						print "<li class='small'><a>" + keywords[i] + "</a></li>";
						
					i += 1;
					
	print '</ul>';
	print '</div>';
	print "</td>";
	print "</tr>";
	print "</table>";
	#print '</img>';
	print '</body>';
	print '</html>';
except Exception as err:
	print err;
	