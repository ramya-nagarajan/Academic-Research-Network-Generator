#!C:/Python27/python.exe
print 'Content-Type:text/plain\n';

from neo4j import GraphDatabase
import urlparse, os;
#import abcd;

#print '<html>'
#print '<head></head><body>'
authors = [];
nodes = [];
pairs = [];
strLst = '';
similar = [];
ids = [];
id = None;
name = urlparse.parse_qs(os.environ['QUERY_STRING'])['name'][0];

db = GraphDatabase("D:\\preethi\\data\\graph1");
with db.transaction:
	relationships = db.relationships;
	
	i = 0;
	n = len(relationships);
	for rel in relationships:
		if str(rel.type) == 'similar_to':
			if (rel.start["name"] != name and rel.end["name"] != name) or (rel.start["name"] == rel.end["name"]):
				#print rel.start["name"];	
				continue;
                #break;
			else:
				if rel.end["name"] == name:
					id = rel.end.id;
					person = rel.start;
					if person['name'] not in authors:
						nodes.append(person);
						ids.append(person.id);
						#print person.id;
						authors.append(person['name']);
				else:
					person = rel.end;
					if person['name'] not in authors:
						nodes.append(person);
						ids.append(person.id);
						#print person.id;
						authors.append(person['name']);
				
	
#print authors;		
#print authors, ";", ids, ";", links, ";", id, ";", link;
if id == None:
	i = 0;
	for rel in relationships:
		if str(rel.type) == 'author_of':
			if rel.start["name"] == name:
				id = rel.start.id;
				break;
print authors, ";", ids, ";", id;
#bothe ends of similar_to are same
#print '</body></html>'
#print 'Preethi,Ramya,Lakshitha,Krupesh,Nandindi,Varsha,Jayant,Suharsha';
#multiple nodes called Pieter Abeel ?
#similar to same person multiple times

#Scale-space and edge detection using anisotropic diffusion
#done till 195 nodes

#pass back id of nodes and relationships